const timeElement = document.querySelector('h1.time');
var t24hrf = 0;
const root = document.querySelector('.root');

async function sleep(ms) {
    return await new Promise(resolve => setTimeout(resolve, ms));
}

(async()=>{
    for (var i = 0; i < 1; i+=0.01){
        await sleep(0.1);
        root.style.opacity = i;
    }
})();

setInterval(function() {
    if (t24hrf) {
        timeElement.innerHTML = `${new Date().getHours()}:${new Date().getMinutes()}`;
    } else {
        timeElement.innerHTML = `${new Date().getHours()}:${new Date().getMinutes()} am`;
    }
}); //change time