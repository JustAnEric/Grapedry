// screen:
// 240 x 240
// 2.5 x 2.5 inches

const { BrowserWindow, shell, safeStorage, app } = require('electron');

(async()=>{
});

app.whenReady().then(() => {
    const win = new BrowserWindow({
        title: 'GrapeDry',
        frame: false,
        width: 240,
        height: 240,
        resizable: false
    });


    win.loadFile('grapepod-boot.html');
});